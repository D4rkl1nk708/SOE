/**
 * SOE Content Script — roda no contexto da página TEC Concursos (MAIN world).
 *
 * Estratégia: intercepta fetch + XHR do TEC em document-start, antes de
 * qualquer código React/Vue do site carregar. Quando captura dados de
 * desempenho, envia para o background service worker via postMessage.
 *
 * Roda em MAIN world para poder monkey-patch window.fetch e XMLHttpRequest.
 */

(function () {
  'use strict';

  if (window.__SOE_INJECTED__) return;
  window.__SOE_INJECTED__ = true;

  const CADERNO_ID = location.pathname.match(/\/cadernos\/(\d+)/)?.[1] || null;

  function parseTecResponse(data) {
    const rows = [];
    let disciplinaAtual = '';

    const candidates = [
      data?.assuntos, data?.estatisticas, data?.items, data?.data,
      data?.questoes_por_assunto, data?.desempenho,
      data?.caderno?.assuntos, data?.caderno?.estatisticas,
      data?.result, data?.results,
      Array.isArray(data) ? data : null,
    ];

    const list = candidates.find(c => Array.isArray(c) && c.length > 0);
    if (!list) return rows;

    const nomePayload =
      data?.caderno?.nome || data?.nome || data?.title ||
      data?.caderno?.disciplina || data?.disciplina || '';

    for (const item of list) {
      if (item.isDisciplina || item.type === 'disciplina' || item.tipo === 'disciplina') {
        disciplinaAtual = item.nome || item.name || item.disciplina || '';
        continue;
      }
      const disc    = item.disciplina || item.materia || item.discipline || item.categoria || disciplinaAtual || nomePayload || 'TEC Concursos';
      const acertos = item.acertos ?? item.corretas ?? item.correct ?? item.hits ?? item.certas ?? 0;
      const erros   = item.erros   ?? item.incorretas ?? item.wrong  ?? item.errors ?? item.erradas ?? 0;
      const nome    = item.assunto || item.nome || item.name || item.topico || item.titulo || '';
      if (nome && (acertos + erros) > 0) {
        rows.push({ disciplina: disc, assunto: nome, acertos: Number(acertos), erros: Number(erros) });
      }
    }
    return rows;
  }

  function isRelevantUrl(url) {
    if (!url) return false;
    const u = url.toString();
    return (
      u.includes('estatisticas') || u.includes('desempenho') ||
      u.includes('assunto')      || u.includes('caderno') ||
      (CADERNO_ID && u.includes(CADERNO_ID))
    );
  }

  let lastScrapedStats = '';

  function scrapeQuestionHeader() {
    const text = document.body?.innerText || '';
    if (!text) return [];

    const statsMatch = text.match(/(?:(\d+)\s*Resolvidas?,\s*)?(\d+)\s*Acertos?\s+e\s+(\d+)\s*Erros?/i);
    const materiaMatch = text.match(/Mat[eé]ria:\s*([^\n]+)/i);
    const assuntoMatch = text.match(/Assunto:\s*([^\n]+)/i);

    if (materiaMatch && assuntoMatch) {
      let disciplina = materiaMatch[1].trim();
      let assunto = assuntoMatch[1].trim();

      // Remove botões/ícones de erro na interface do React
      disciplina = disciplina.replace(/[\u2715\u2716\u2297\u2A2F\u00D7]/g, '').trim();
      assunto = assunto.replace(/[\u2715\u2716\u2297\u2A2F\u00D7]/g, '').trim();
      
      let acertos = 0;
      let erros = 0;

      if (statsMatch) {
         acertos = parseInt(statsMatch[2], 10) || 0;
         erros = parseInt(statsMatch[3], 10) || 0;
      }

      return [{ disciplina, assunto, acertos, erros }];
    }
    return [];
  }

  let questionStartTime = Date.now();
  let lastUrl = location.href;
  const seenQuestions = {};
  
  // Reseta o timer toda vez que mudar de questão (URL) e detecta questões já respondidas
  setInterval(() => {
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      questionStartTime = Date.now();
    }

    // Marca silenciosamente questões que já vieram respondidas ao carregar a página
    const bodyText = document.body.innerText || '';
    const headerMatch = bodyText.match(/#(\d+)\s+([^-]+)/);
    if (headerMatch) {
       const qId = headerMatch[1];
       if (!seenQuestions[qId]) {
          seenQuestions[qId] = Date.now();
       }
       
       // Dá uma janela de 4.5 segundos para a mensagem aparecer.
       // Se aparecer neste intervalo, é certeza que a questão JÁ FOI carregada respondida no passado.
       if (Date.now() - seenQuestions[qId] < 4500) {
          const acertoMatch = bodyText.match(/Você acertou!/i);
          const erroMatch = bodyText.match(/Você errou!/i);
          if (acertoMatch || erroMatch) {
             const storageKey = 'soe_scored_' + qId;
             if (!sessionStorage.getItem(storageKey)) {
                 sessionStorage.setItem(storageKey, '1');
                 console.log('[SOE] Questão', qId, 'já estava resolvida (silenciado na janela de segurança).');
             }
          }
       }
    }
  }, 250);

  function tryScrapeDOM() {
    const rows = scrapeQuestionHeader();
    
    // Obter dados da questao
    const bodyText = document.body.innerText;
    const headerMatch = bodyText.match(/#(\d+)\s+([^-]+)/);
    let questionId = headerMatch ? headerMatch[1] : null;
    
    const acertoMatch = bodyText.match(/Você acertou!/i);
    const erroMatch = bodyText.match(/Você errou!/i);
    
    if (questionId && (acertoMatch || erroMatch)) {
       const storageKey = 'soe_scored_' + questionId;
       if (!sessionStorage.getItem(storageKey)) {
          const timeSpentSeconds = Math.max(1, Math.floor((Date.now() - questionStartTime) / 1000));
          if (timeSpentSeconds < 4) {
             sessionStorage.setItem(storageKey, '1');
             return;
          }
          
          sessionStorage.setItem(storageKey, '1');
          
          const isError = !!erroMatch;
          
          // Reseta o tempo para a PROXIMA questao na mesma pagina começar a rodar a partir de agora
          questionStartTime = Date.now();
          
          if (rows.length > 0) {
             console.log('[SOE] Incrementando stats para', rows[0].assunto, '-', timeSpentSeconds, 'segundos');
             window.postMessage({
               type: 'SOE_TEC_INCREMENT_STATS',
               payload: {
                 cadernoId: CADERNO_ID || location.pathname.split('/').filter(Boolean).pop() || 'unknown',
                 cadernoUrl: location.href,
                 disciplina: rows[0].disciplina,
                 assunto: rows[0].assunto,
                 correctAdd: isError ? 0 : 1,
                 errorAdd: isError ? 1 : 0,
                 timeSpentSeconds: timeSpentSeconds
               }
             }, '*');

             // Feature 3: Sirene de Ilusão de Competência (Tracker de Fadiga Sequencial)
             if (isError) {
                const now = Date.now();
                let errorTimes = JSON.parse(sessionStorage.getItem('soe_error_times_v2') || '[]');
                errorTimes = errorTimes.filter(t => now - t.time < 3 * 60 * 1000); // 3 minutos de janela
                errorTimes.push({ time: now, subject: rows[0].assunto });
                sessionStorage.setItem('soe_error_times_v2', JSON.stringify(errorTimes));
                
                const sameSubjectErrors = errorTimes.filter(t => t.subject === rows[0].assunto);
                if (sameSubjectErrors.length >= 3) {
                   showCompetenceIllusionSiren(rows[0].assunto, sameSubjectErrors.length);
                   sessionStorage.setItem('soe_error_times_v2', '[]'); // reseta para nao repetir sem parar
                }
             } else {
                // Acertou, reseta os erros daquele assunto
                let errorTimes = JSON.parse(sessionStorage.getItem('soe_error_times_v2') || '[]');
                errorTimes = errorTimes.filter(t => t.subject !== rows[0].assunto);
                sessionStorage.setItem('soe_error_times_v2', JSON.stringify(errorTimes));
             }
          }
          
          if (isError) {
            const wq = scrapeWrongQuestion(bodyText, document.body);
            if (wq && wq.statement) {
               wq.disciplina = rows.length > 0 ? rows[0].disciplina : '';
               wq.assunto = rows.length > 0 ? rows[0].assunto : '';
               wq.timeSpentSeconds = timeSpentSeconds;
               window.postMessage({ type: 'SOE_TEC_WRONG_QUESTION', payload: wq }, '*');
            }
          }
       }
    }
  }

  function showCompetenceIllusionSiren(assunto, count) {
     const siren = document.createElement('div');
     siren.style.cssText = `
       position: fixed; top: 0; left: 0; width: 100%; height: 100%;
       background: rgba(15, 23, 42, 0.98); z-index: 9999999;
       display: flex; flex-direction: column; align-items: center; justify-content: center;
       color: white; font-family: sans-serif; text-align: center; padding: 20px;
       backdrop-filter: blur(10px);
     `;
     siren.innerHTML = `
       <div style="font-size: 60px; margin-bottom: 20px;">🚨</div>
       <h1 style="font-size: 32px; margin-bottom: 15px; color: #f87171;">Alerta de Ilusão de Competência</h1>
       <p style="font-size: 20px; line-height: 1.5; max-width: 600px; color: #cbd5e1; margin-bottom: 30px;">
         Você errou <strong>${count} questões</strong> quase sequenciais de <em>${assunto}</em> num curto intervalo de tempo.<br><br>
         Insistir agora é desperdiçar energia mental e memorizar o erro. Dê um passo atrás. Vá revisar seu material, grifos ou anotações.
       </p>
       <button id="soe-dismiss-siren" style="padding: 12px 24px; font-size: 18px; border-radius: 8px; border: none; background: #3b82f6; color: white; cursor: pointer; font-weight: bold; transition: all 0.2s;">
         Entendi (Voltar)
       </button>
     `;
     document.body.appendChild(siren);
     document.getElementById('soe-dismiss-siren').addEventListener('click', () => {
         siren.remove();
     });
  }

  function scrapeWrongQuestion(text, bodyElement) {
    const errorMatch = text.match(/Você errou!(?:[\s\S]{0,300}Gabarito:\s*([A-E]|[CERTORADcertorad]+\b))?/i);
    // Even if Gabarito is not found, we should still capture the question since it says "Você errou!".
    if (!text.match(/Você errou!/i)) return null;

    const headerMatch = text.match(/#(\d+)\s+([^-]+)\s*-\s*(\d{4})?\s*-\s*([^\n]+)/);
    let questionId = headerMatch ? headerMatch[1] : '';
    let banca = headerMatch ? headerMatch[2].trim() : '';
    let year = headerMatch && headerMatch[3] ? parseInt(headerMatch[3], 10) : new Date().getFullYear();
    let contest = headerMatch ? headerMatch[4].trim() : '';

    const alternativesRegex = /\(\s*([A-E])\s*\)\s*([^\n]+)/g;
    let alternatives = [];
    let m;
    let firstAltIndex = -1;
    while ((m = alternativesRegex.exec(text)) !== null) {
       if (firstAltIndex === -1) firstAltIndex = m.index;
       alternatives.push({ letter: m[1], text: m[2].trim() });
    }

    let statement = '';
    if (headerMatch && firstAltIndex !== -1) {
       statement = text.substring(headerMatch.index + headerMatch[0].length, firstAltIndex).trim();
    }

    let correctAnswerText = errorMatch && errorMatch[1] ? errorMatch[1].trim() : '';
    let correctAnswer = '';
    
    if (correctAnswerText) {
        let matchedAlt = alternatives.find(a => a.text.toLowerCase() === correctAnswerText.toLowerCase() || a.letter.toLowerCase() === correctAnswerText.toLowerCase());
        if (matchedAlt) correctAnswer = matchedAlt.letter;
        else correctAnswer = correctAnswerText.charAt(0).toUpperCase();
    }

    let userAnswer = '';
    // Optional logic to guess userAnswer for C/E
    if (!userAnswer && alternatives.length === 2 && (alternatives[0].letter === 'C' || alternatives[1].letter === 'C')) {
       userAnswer = correctAnswer === 'C' ? 'E' : (correctAnswer === 'E' ? 'C' : '');
    }
    
    // Feature 2: Sequestro Silencioso dos Comentários
    let resolution = '';
    if (bodyElement) {
       const resNode = bodyElement.querySelector('.resolucao-professor, .resolucao, [class*="resolution"], [class*="resolucao"], .feedback-prof');
       if (resNode) {
          // Usa textContent para pegar até o que pode estar invisível/display:none
          resolution = resNode.textContent.trim().replace(/\s+/g, ' ');
       }
    }
    
    return { questionId, banca, year, contest, statement, alternatives, correctAnswer, userAnswer, resolution };
  }

  function dispatch(rows, sourceUrl) {
    if (!rows || rows.length === 0) return;
    window.postMessage({
      type: 'SOE_TEC_DATA',
      payload: {
        cadernoId:  CADERNO_ID || location.pathname.split('/').filter(Boolean).pop() || 'unknown',
        cadernoUrl: location.href,
        disciplina: rows[0]?.disciplina || '',
        rows,
        sourceUrl,
      }
    }, '*');
  }

  // Intercepta fetch
  const _fetch = window.fetch;
  window.fetch = async function (...args) {
    const response = await _fetch.apply(this, args);
    try {
      const url = typeof args[0] === 'string' ? args[0] : args[0]?.url || '';
      
      // Sempre que houver um fetch (ex: enviar resposta), checa o DOM pouco depois
      if (url.includes('api')) {
        setTimeout(tryScrapeDOM, 1000);
      }

      if (isRelevantUrl(url)) {
        const ct = response.headers.get('content-type') || '';
        if (ct.includes('json')) {
          response.clone().json().then(data => {
            const rows = parseTecResponse(data);
            if (rows.length > 0) {
              console.log('[SOE] capturados', rows.length, 'assuntos via fetch');
              dispatch(rows, url);
            }
          }).catch(() => {});
        }
      }
    } catch (_) {}
    return response;
  };

  // Intercepta XHR (fallback)
  const _XHROpen = XMLHttpRequest.prototype.open;
  const _XHRSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    this._soe_url = url;
    return _XHROpen.apply(this, [method, url, ...rest]);
  };
  XMLHttpRequest.prototype.send = function (...args) {
    this.addEventListener('load', function () {
      try {
        const url = this._soe_url || '';
        
        if (url.includes('api')) {
           setTimeout(tryScrapeDOM, 1000);
        }

        if (!isRelevantUrl(url)) return;
        const ct = this.getResponseHeader('content-type') || '';
        if (!ct.includes('json')) return;
        const data = JSON.parse(this.responseText);
        const rows = parseTecResponse(data);
        if (rows.length > 0) {
          console.log('[SOE] capturados', rows.length, 'assuntos via XHR');
          dispatch(rows, url);
        }
      } catch (_) {}
    });
    return _XHRSend.apply(this, args);
  };

  // Scraping de tabela HTML (fallback quando API não interceptada)
  function scrapeHtmlTable() {
    const rows = [];
    let disciplinaAtual = '';
    const trs = document.querySelectorAll('table tr, [class*="table"] [class*="row"]');
    for (const tr of trs) {
      const tds = Array.from(tr.querySelectorAll('td, [class*="cell"]'));
      if (tds.length === 0) continue;
      const textos = tds.map(td => td.innerText.trim());
      const numeros = textos.filter(t => /^\d+$/.test(t)).map(Number);
      if (numeros.length < 2 && textos[0] && textos[0].length > 3) {
        const hasBold = tr.querySelector('strong, b, [style*="bold"], [class*="bold"], [class*="header"], [class*="disciplina"]');
        const hasColspan = tds.some(td => parseInt(td.getAttribute('colspan') || '1') > 2);
        if (hasBold || hasColspan || tds.length === 1) {
          disciplinaAtual = textos[0].replace(/\s*\([^)]*\)\s*$/, '').trim();
          continue;
        }
      }
      if (numeros.length >= 2 && textos[0] && disciplinaAtual) {
        rows.push({ disciplina: disciplinaAtual, assunto: textos[0], acertos: numeros[0], erros: numeros[1] });
      }
    }
    if (rows.length > 0) {
      console.log('[SOE] capturados', rows.length, 'assuntos via HTML scraping');
      dispatch(rows, location.href);
    }
    return rows.length;
  }

  document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
      tryScrapeDOM();
      if (scrapeHtmlTable() === 0) {
        setTimeout(scrapeHtmlTable, 3000);
      }
      injectSOEHud();
    }, 2000);
    
    // Configura observer simples de clicks (ex: no botão de avançar/responder) para garantir!
    document.body.addEventListener('click', () => {
       setTimeout(tryScrapeDOM, 1500); 
    });
  });

  function sendBgMessage(type, payload) {
    return new Promise((resolve, reject) => {
      const messageId = Math.random().toString(36).substring(7);
      const handler = (e) => {
         if (e.data?.type === type + '_RESPONSE' && e.data?.messageId === messageId) {
            window.removeEventListener('message', handler);
            clearTimeout(timeout);
            if (e.data.error || e.data.response?.ok === false) {
               reject(new Error(e.data.error || e.data.response?.error));
            } else {
               resolve(e.data.response?.data);
            }
         }
      };
      window.addEventListener('message', handler);
      window.postMessage({ type, payload, messageId }, '*');
      
      const timeout = setTimeout(() => {
         window.removeEventListener('message', handler);
         reject(new Error("Timeout calling extension background"));
      }, 15000);
    });
  }

  // ----------------------------------------------------------------------
  // FEATURE 4: Modo Prova (Anti-Ansiedade) & FEATURE 1: Ai Mentor
  // ----------------------------------------------------------------------
  function injectSOEHud() {
     if (document.getElementById('soe-hud')) return;

     const hud = document.createElement('div');
     hud.id = 'soe-hud';
     hud.innerHTML = `
        <div style="font-weight: 600; margin-bottom: 8px; color: #fff;">SOE Mentor</div>
        <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; font-size: 13px; color: #cbd5e1; margin-bottom: 8px;">
          <input type="checkbox" id="soe-focus-toggle">
          Modo Anti-Ansiedade
        </label>
        <button id="soe-panic-btn" style="width: 100%; padding: 6px; background: rgba(59, 130, 246, 0.2); border: 1px solid rgba(59, 130, 246, 0.4); color: #60a5fa; border-radius: 6px; font-size: 13px; cursor: pointer; display: flex; justify-content: center; align-items: center; gap: 6px; transition: background 0.2s;">
           💡 Me ajude, IA
        </button>
     `;
     hud.style.cssText = `
        position: fixed;
        bottom: 20px;
        right: 20px;
        background: rgba(15, 23, 42, 0.95);
        border: 1px solid rgba(255, 255, 255, 0.1);
        padding: 16px;
        border-radius: 12px;
        box-shadow: 0 10px 25px -5px rgba(0,0,0,0.5);
        z-index: 999999;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        backdrop-filter: blur(8px);
        transition: all 0.3s ease;
     `;

     document.body.appendChild(hud);

     const style = document.createElement('style');
     style.id = 'soe-focus-styles';
     style.innerHTML = `
        body.soe-focus-mode .feedbacks,
        body.soe-focus-mode [class*="feedback"],
        body.soe-focus-mode [class*="feedback-erro"],
        body.soe-focus-mode [class*="feedback-acerto"],
        body.soe-focus-mode [class*="resolution"],
        body.soe-focus-mode .resolucao-professor {
           display: none !important;
        }
        body.soe-focus-mode .botoes span {
           opacity: 0.5;
           pointer-events: none;
        }
     `;
     document.head.appendChild(style);

     const toggle = document.getElementById('soe-focus-toggle');
     
     // Load state from local storage
     const isFocus = localStorage.getItem('soe_focus_mode') === 'true';
     toggle.checked = isFocus;
     if (isFocus) document.body.classList.add('soe-focus-mode');

     toggle.addEventListener('change', (e) => {
        if (e.target.checked) {
           document.body.classList.add('soe-focus-mode');
           localStorage.setItem('soe_focus_mode', 'true');
        } else {
           document.body.classList.remove('soe-focus-mode');
           localStorage.setItem('soe_focus_mode', 'false');
        }
     });

     document.getElementById('soe-panic-btn').addEventListener('click', async () => {
         const btn = document.getElementById('soe-panic-btn');
         btn.disabled = true;
         btn.innerText = 'Consultando...';

         // Captura contexto local
         let text = document.body.innerText;
         const headerMatch = text.match(/#(\d+)\s+([^-]+)\s*-\s*(\d{4})?\s*-\s*([^\n]+)/);
         let qText = "";
         if (headerMatch) {
            text = text.substring(headerMatch.index);
         }
         qText = text;
         
         // Limpa os comentários de outros alunos/professores cortando a string
         const cutoffs = [/Você errou!/, /Você acertou!/, /Gabarito:/, /Resolução do Professor/i, /Comentários da Comunidade/i, /Fórum/i];
         let earliestCutoff = qText.length;
         for (const regex of cutoffs) {
            const match = qText.match(regex);
            if (match && match.index < earliestCutoff) {
               earliestCutoff = match.index;
            }
         }
         
         if (earliestCutoff > 0 && earliestCutoff < qText.length) {
            qText = qText.substring(0, earliestCutoff);
         }
         
         qText = qText.substring(0, 1500); // Passamos apenas a questão e alternativas limpas

         let fatigueCount = 0;
         let subjectName = "";
         let discName = "";
         try {
            const rows = scrapeQuestionHeader();
            if (rows.length > 0) {
              subjectName = rows[0].assunto;
              discName = rows[0].disciplina;
              const errorTimes = JSON.parse(sessionStorage.getItem('soe_error_times_v2') || '[]');
              fatigueCount = errorTimes.filter(t => t.subject === subjectName).length;
            }
         } catch(e) {}

         let questionIdStr = headerMatch ? headerMatch[1] : '';

         try {
            const data = await sendBgMessage('SOE_TEC_AI_MENTOR', { 
               questionId: questionIdStr,
               questionText: qText,
               subject: subjectName,
               discipline: discName,
               fatigue: fatigueCount
            });
            
            if (data?.text) {
               showMentorModal(data.text);
            } else {
               alert("Mentor respondeu vazio ou sem chave de API.");
            }
         } catch(e) {
            alert("Falha de conexão: " + e.message);
         }
         
         btn.disabled = false;
         btn.innerText = '💡 Me ajude, IA';
     });
  }

  function showMentorModal(text) {
     const modal = document.createElement('div');
     modal.style.cssText = `
       position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);
       background: #1e293b; color: white; padding: 25px; border-radius: 12px;
       box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5); z-index: 9999999;
       max-width: 600px; width: 90%; font-family: sans-serif; line-height: 1.6;
       border: 1px solid #334155;
     `;
     modal.innerHTML = `
       <h2 style="margin: 0 0 15px 0; color: #60a5fa; display: flex; align-items: center; gap: 8px;">
          <span style="font-size: 24px;">💡</span> SOE Mentor Socrático
       </h2>
       <div style="font-size: 15px; color: #e2e8f0; white-space: pre-wrap; margin-bottom: 20px; max-height: 50vh; overflow-y: auto;">${text.replace(/</g, "&lt;")}</div>
       <button id="soe-close-mentor" style="width: 100%; padding: 10px; border-radius: 6px; border: none; background: #3b82f6; color: white; cursor: pointer; font-weight: bold;">Fechar</button>
     `;
     document.body.appendChild(modal);
     document.getElementById('soe-close-mentor').addEventListener('click', () => modal.remove());
  }

  console.log('[SOE] content script ativo');
})();
